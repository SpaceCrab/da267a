#ifndef RANDOM_H_
#define RANDOM_H_

// get random number between min and max
int getRandomRange(int min, int max);
#endif
