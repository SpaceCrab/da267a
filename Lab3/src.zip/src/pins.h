#ifndef PINS_H_
#define PINS_H_

#include <stdint.h>

//intializes the 4 pins
void initPins();

//switches state of LEDA
void setLEDA(uint8_t level);

#endif
